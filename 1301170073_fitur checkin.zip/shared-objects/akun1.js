module.exports = [
    {
        email: "admin1",
        password: "admin123",
        nama:"pratama yoga",
        nik:"1234567891234567",
        kamar:"301",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Michael 6",
        nik:"1234567891234568",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Michael",
        nik:"123456789123456813",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Michael",
        nik:"123456789123456a",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Michael",
        nik:"123456789123456?",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"",
        nik:"",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Pratama yoga",
        nik:"1234567891234567",
        kamar:"302",
        fasilitas:"A1"
    },
    {
        email: "admin1",
        password: "admin123",
        nama:"Michael",
        nik:"1234567891234568",
        kamar:"303",
        fasilitas:"A1"
    }
]