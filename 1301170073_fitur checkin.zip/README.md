# Selenium-Training
Training automation test using selenium, I do this thing because of my lecture task, Really !

## How to use 

1. `npm install --save`
2. Add your own web url
3. Change the case number in the `checkin1-steps`
4. Change the `index` on every field nama, nik, fasilitas, and kamar
5. Search element by `Inspect element > choose element > copy > copy as xpath`
6. Put in the xpath in the folder **page-objects**
7. Run command : `node ./node_modules/selenium-cucumber-js/index.js -f features/[your feature file]`

## For Collaborator !!!
- Please make your **`own branch`**
- Don't make **`pull request`**
- But if you want to make PR, assign to me **evanezcent**

> It's because the submitting format that and avoid error because a same scenario

More ? read here [Selenium](https://www.npmjs.com/package/selenium-cucumber-js)
